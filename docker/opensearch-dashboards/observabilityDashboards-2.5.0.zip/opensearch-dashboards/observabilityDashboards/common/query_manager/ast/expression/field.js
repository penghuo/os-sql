"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.Field = void 0;

var _node = require("../node");

/*
 * Copyright OpenSearch Contributors
 * SPDX-License-Identifier: Apache-2.0
 */
class Field extends _node.PPLNode {
  constructor(name, children, fieldExpression) {
    super(name, children);
    this.fieldExpression = fieldExpression;
  }

  getTokens() {
    var _this$fieldExpression;

    return {
      name: (_this$fieldExpression = this.fieldExpression) !== null && _this$fieldExpression !== void 0 ? _this$fieldExpression : ''
    };
  }

  toString() {
    var _this$fieldExpression2;

    return (_this$fieldExpression2 = this.fieldExpression) !== null && _this$fieldExpression2 !== void 0 ? _this$fieldExpression2 : '';
  }

}

exports.Field = Field;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImZpZWxkLnRzIl0sIm5hbWVzIjpbIkZpZWxkIiwiUFBMTm9kZSIsImNvbnN0cnVjdG9yIiwibmFtZSIsImNoaWxkcmVuIiwiZmllbGRFeHByZXNzaW9uIiwiZ2V0VG9rZW5zIiwidG9TdHJpbmciXSwibWFwcGluZ3MiOiI7Ozs7Ozs7QUFLQTs7QUFMQTtBQUNBO0FBQ0E7QUFDQTtBQUlPLE1BQU1BLEtBQU4sU0FBb0JDLGFBQXBCLENBQTRCO0FBQ2pDQyxFQUFBQSxXQUFXLENBQUNDLElBQUQsRUFBZUMsUUFBZixFQUFpREMsZUFBakQsRUFBMEU7QUFDbkYsVUFBTUYsSUFBTixFQUFZQyxRQUFaO0FBRG1GLFNBQXpCQyxlQUF5QixHQUF6QkEsZUFBeUI7QUFFcEY7O0FBRURDLEVBQUFBLFNBQVMsR0FBRztBQUFBOztBQUNWLFdBQU87QUFBRUgsTUFBQUEsSUFBSSwyQkFBRSxLQUFLRSxlQUFQLHlFQUEwQjtBQUFoQyxLQUFQO0FBQ0Q7O0FBRURFLEVBQUFBLFFBQVEsR0FBVztBQUFBOztBQUNqQixxQ0FBTyxLQUFLRixlQUFaLDJFQUErQixFQUEvQjtBQUNEOztBQVhnQyIsInNvdXJjZXNDb250ZW50IjpbIi8qXG4gKiBDb3B5cmlnaHQgT3BlblNlYXJjaCBDb250cmlidXRvcnNcbiAqIFNQRFgtTGljZW5zZS1JZGVudGlmaWVyOiBBcGFjaGUtMi4wXG4gKi9cblxuaW1wb3J0IHsgUFBMTm9kZSB9IGZyb20gJy4uL25vZGUnO1xuXG5leHBvcnQgY2xhc3MgRmllbGQgZXh0ZW5kcyBQUExOb2RlIHtcbiAgY29uc3RydWN0b3IobmFtZTogc3RyaW5nLCBjaGlsZHJlbjogQXJyYXk8UFBMTm9kZT4sIHByaXZhdGUgZmllbGRFeHByZXNzaW9uOiBzdHJpbmcpIHtcbiAgICBzdXBlcihuYW1lLCBjaGlsZHJlbik7XG4gIH1cblxuICBnZXRUb2tlbnMoKSB7XG4gICAgcmV0dXJuIHsgbmFtZTogdGhpcy5maWVsZEV4cHJlc3Npb24gPz8gJycgfTtcbiAgfVxuXG4gIHRvU3RyaW5nKCk6IHN0cmluZyB7XG4gICAgcmV0dXJuIHRoaXMuZmllbGRFeHByZXNzaW9uID8/ICcnO1xuICB9XG59XG4iXX0=